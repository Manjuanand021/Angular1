import PredictiveSearchController from './predictiveSearchController';

//Register all the controllers here
angular.module('PredictiveSearchApp').controller('PredictiveSearchController', PredictiveSearchController);