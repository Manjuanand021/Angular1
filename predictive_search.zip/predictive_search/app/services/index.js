import PredictiveSearchService from './predictiveSearchService';

//Register all the services here
angular.module('PredictiveSearchApp').service('PredictiveSearchService', PredictiveSearchService)