'use strict'

//Angular main app
var filterApp = angular.module('PredictiveSearchApp', []);

//services
require('./services');

//controllers
require('./controllers');

//directives


//filters