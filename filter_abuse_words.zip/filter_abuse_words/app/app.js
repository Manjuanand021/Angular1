'use strict'

//Angular main app
var filterApp = angular.module('FilterApp', []);

//services
require('./services');

//controllers
require('./controllers');

//directives


//filters