import FilterController from './filterController';

//Register all the controllers here
angular.module('FilterApp').controller('FilterController', FilterController);