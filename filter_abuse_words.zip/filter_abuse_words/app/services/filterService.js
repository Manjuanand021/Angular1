function FilterService() {
    var name = 'Manjuanand';
    return {
        getName: function () {
            return name;
        }
    }
}

export default FilterService;