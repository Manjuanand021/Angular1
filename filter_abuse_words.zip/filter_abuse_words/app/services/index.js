import FilterService from './filterService';

//Register all the services here
angular.module('FilterApp').service('FilterService', FilterService)