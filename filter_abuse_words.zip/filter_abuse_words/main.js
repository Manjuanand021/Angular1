//This file contains all the project dependenices
require('./app/app');

//Other dependencies here
require('./style.scss');